#!/usr/bin/env python3

# Created by Ethan Prieur
# Created on March 2022
# This is file contains constants for another file

TAU = 6.28
