# ICS3U-Unit2-03-Python

[![GitHub's Super Linter](https://github.com/Ethan-Prieur1/ICS3U-Unit2-03-Python/workflows/GitHub's%20Super%20Linter/badge.svg)](https://github.com/Ethan-Prieur1/ICS3U-Unit2-03-Python/actions)
